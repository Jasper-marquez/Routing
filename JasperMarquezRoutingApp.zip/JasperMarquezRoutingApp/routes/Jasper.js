import express from "express";
const router = express.Router();
router.get("/jasper", (req, res) =>{
    res.json({
        name : "jasper",
        age : "20"
    });
});

export default router;