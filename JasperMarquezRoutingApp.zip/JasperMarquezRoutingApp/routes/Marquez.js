import express from "express";
const router = express.Router();
router.get("/marquez", (req, res) =>{
    res.status(200).send("Hello Marquez");
});

export default router;