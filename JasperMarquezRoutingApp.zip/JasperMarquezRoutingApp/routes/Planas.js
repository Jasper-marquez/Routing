import express from "express";
const router = express.Router();
router.get("/planas", (req, res) =>{
    res.send("Hello Planas!");
});

export default router;