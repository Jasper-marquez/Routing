import express from "express";
const router = express.Router();
router.get("/jasperPlan", (req, res) =>{
    res.send("<h1>Hello JasperPlan</h1>");
});

export default router;