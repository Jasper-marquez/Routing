import express from "express";
const router = express.Router();
router.get("/jasperMar", (req, res) =>{
    res.end("Hello JasperMar!");
});

export default router;